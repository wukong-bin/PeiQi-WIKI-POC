# Linux

#### Linux sudo权限提升漏洞 CVE-2021-3156

#### Linux kernel权限提升漏洞 CVE-2021-3493

